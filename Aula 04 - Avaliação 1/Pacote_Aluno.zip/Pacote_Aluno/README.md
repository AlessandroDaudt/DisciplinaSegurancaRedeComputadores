# Laboratório de Segurança de Redes — Força Bruta e Criptografia

Laboratório educacional isolado para demonstrar:

1. análise básica de PCAP;
2. descoberta de um nome de usuário em HTTP;
3. força bruta **online** contra uma aplicação propositalmente vulnerável;
4. autenticação e download de um artefato;
5. força bruta **offline** de um PIN de baixa entropia usado para derivar uma chave AES-256;
6. discussão de mitigações.

## Pré-requisitos
- Windows 10/11;
- PowerShell 5.1 ou superior;
- Docker Desktop com `docker compose`;
- Wireshark.

Nenhum script desta atividade solicita elevação administrativa. O Docker precisa estar previamente instalado e utilizável pelo usuário.

## Início rápido
No PowerShell, dentro desta pasta:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Iniciar-Laboratorio.ps1
```

Depois:

```powershell
.\ferramenta\Laboratorio-Seguranca.ps1
```

Abra `captura\captura_login.pcap` no Wireshark e siga `roteiro\ATIVIDADE.md`.

## Segurança do laboratório
O serviço Docker é publicado apenas em `127.0.0.1:8080`. A GUI PowerShell também possui o alvo fixado em localhost. O material foi criado apenas para o ambiente didático local.

## Encerrar
```powershell
.\Parar-Laboratorio.ps1
```
