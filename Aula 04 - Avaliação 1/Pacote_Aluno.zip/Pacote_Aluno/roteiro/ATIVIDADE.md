# Atividade Avaliada — Força Bruta, PCAP e Criptografia

## Objetivo
Analisar uma captura simples, identificar o usuário, demonstrar o impacto de uma senha fraca e recuperar um arquivo protegido por uma chave derivada de PIN de baixa entropia.

## Regras
- Use somente o ambiente local fornecido pela disciplina.
- Não altere os arquivos do servidor Docker.
- Não use a ferramenta contra endereços externos. Ela já está fixada em `127.0.0.1`.

## Etapa 1 — PCAP
Abra `captura/captura_login.pcap` no Wireshark. A captura possui apenas uma conexão simples.

Sugestões de filtro:
- `http`
- `http.request.method == POST`

Responda:
1. Qual o IP do cliente?
2. Qual o IP do servidor?
3. Qual método HTTP aparece?
4. Qual usuário está presente na requisição?
5. A senha aparece na captura?

## Etapa 2 — Força bruta no login
1. Execute `ferramenta/Laboratorio-Seguranca.ps1`.
2. Digite o usuário obtido no PCAP.
3. Inicie a busca de senha.
4. Registre a senha encontrada e o tempo aproximado.
5. Abra `http://127.0.0.1:8080`, autentique-se e baixe `desafio.enc`.

## Etapa 3 — Força bruta criptográfica
1. Na segunda aba da ferramenta, selecione `desafio.enc`.
2. Inicie a busca do PIN.
3. Ao final, a ferramenta criará `resultado/documentos.zip` e extrairá os documentos.
4. Localize o código de conclusão.

## Questões finais
6. Qual controle reduziria diretamente o ataque de força bruta contra o login? Cite três.
7. O arquivo usa AES-256. Por que ainda foi possível recuperar o conteúdo rapidamente?
8. Qual é aproximadamente a entropia máxima de um PIN decimal de 6 dígitos?
9. Qual a diferença entre força bruta online contra login e força bruta offline contra um arquivo?
10. Cite uma melhoria para cada etapa do laboratório.
