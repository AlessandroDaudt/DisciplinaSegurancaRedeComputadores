# Folha de Respostas

1. IP do cliente:
2. IP do servidor:
3. Método HTTP:
4. Usuário:
5. A senha aparece no PCAP?

Senha encontrada no login:
Tempo aproximado:

PIN encontrado no arquivo:
Código de conclusão:

6. Três controles contra força bruta:

7. Por que AES-256 pôde ser vencido neste cenário?

8. Entropia aproximada do PIN de 6 dígitos:

9. Online x offline:

10. Melhorias propostas:
