# Pacote individual do aluno aluno01

Este pacote Ã© exclusivo de um aluno da turma de 12 pessoas. Ele contÃ©m um PCAP prÃ³prio, mas aponta para a mesma aplicaÃ§Ã£o didÃ¡tica local, que mantÃ©m as 12 contas e os 12 materiais criptografados.

## PrÃ©-requisitos

- Windows 10/11;
- Windows PowerShell 5.1 ou superior;
- Docker Desktop com `docker compose`;
- Wireshark.

O primeiro build pode precisar de internet para obter `python:3.13-slim` e Flask. O uso da aplicaÃ§Ã£o depois do build ocorre em `127.0.0.1`.

## InÃ­cio rÃ¡pido

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Iniciar-Laboratorio.ps1
```

Depois, abra `captura\captura_login.pcap` no Wireshark e execute:

```powershell
.\ferramenta\Laboratorio-Seguranca.ps1
```

Use somente o usuÃ¡rio encontrado no PCAP deste pacote. ApÃ³s descobrir a senha e autenticar no portal em `http://127.0.0.1:8080`, baixe o material `material_*.enc` associado Ã  sessÃ£o.

## SeguranÃ§a do laboratÃ³rio

O alvo da ferramenta Ã© fixo em localhost. Os dados sÃ£o fictÃ­cios e a vulnerabilidade Ã© intencional: a atividade demonstra forÃ§a bruta online, forÃ§a bruta offline de um PIN de seis dÃ­gitos e o impacto de controles de autenticaÃ§Ã£o ausentes.

NÃ£o use a ferramenta contra redes, contas ou serviÃ§os externos.

## Encerrar

```powershell
.\Parar-Laboratorio.ps1
```
