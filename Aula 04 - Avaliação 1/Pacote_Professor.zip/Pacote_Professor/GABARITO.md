# Gabarito do Professor

## Segredos do desafio
- Usuário no PCAP: `aluno07`
- Senha do portal: `7341`
- PIN do arquivo: `042731`
- Código de conclusão: `SR-2026-ALFA`

## PCAP
- Cliente: `192.168.56.10`
- Servidor: `192.168.56.20`
- Método: `POST`
- Endpoint: `/identificar`
- Corpo: contém **somente o usuário**. Não contém senha.

## Conceitos esperados
- Login: ausência de rate limiting, lockout e MFA permite automação.
- Arquivo: AES-256 é forte, mas a chave é derivada de um PIN decimal de seis dígitos. O espaço efetivo é de apenas 1.000.000 candidatos, aproximadamente 19,93 bits de entropia máxima.
- Online: limitado por rede/servidor e detectável. Offline: após obter o arquivo, as tentativas podem ser feitas localmente sem o servidor observar cada tentativa.

## Sugestão de nota (10 pontos)
- PCAP e usuário: 2,0
- Recuperação da senha: 2,0
- Download e recuperação do arquivo: 2,0
- Código de conclusão: 1,0
- Mitigações e explicação de entropia: 3,0
