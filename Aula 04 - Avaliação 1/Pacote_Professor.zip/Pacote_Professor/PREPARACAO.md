# Preparação da Aula

1. Entregue aos alunos **somente** `Pacote_Aluno.zip`.
2. Valide previamente que Docker Desktop e Wireshark estão instalados.
3. Rode `Iniciar-Laboratorio.ps1` em uma máquina da sala para confirmar acesso a `http://127.0.0.1:8080`.
4. O PCAP é sintético e contém cinco frames: handshake TCP simplificado, uma requisição HTTP e ACK.
5. A requisição HTTP contém `username=...` e deliberadamente não contém campo de senha.
6. O PIN do arquivo tem seis dígitos, mas foi escolhido em uma posição relativamente inicial do espaço de busca para manter a duração da atividade curta em máquinas comuns.
7. Se necessário, reduza o custo temporal do login escolhendo uma senha numérica menor; isso exige atualizar o hash no `docker-compose.yml`.

8. O pacote do aluno recebe o servidor como bytecode Python (`app.pyc`) para reduzir inspeção casual do código durante a avaliação. O fonte legível está neste pacote do professor.
