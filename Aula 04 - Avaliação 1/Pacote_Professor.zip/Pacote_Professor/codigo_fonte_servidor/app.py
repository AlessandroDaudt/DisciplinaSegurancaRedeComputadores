from flask import Flask, render_template, request, redirect, url_for, session, send_file, jsonify
import hashlib, os, logging
from pathlib import Path

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "lab-only-secret")
logging.getLogger("werkzeug").setLevel(logging.ERROR)

USER_HASH = os.environ["LAB_USER_SHA256"]
PASSWORD_HASH = os.environ["LAB_PASSWORD_SHA256"]
SALT = "lab-salt-2026:"
DATA_FILE = Path("/app/dados/desafio.enc")

def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def valid_credentials(username: str, password: str) -> bool:
    return (
        sha256_text(username) == USER_HASH
        and sha256_text(SALT + password) == PASSWORD_HASH
    )

@app.get("/")
def index():
    return render_template("login.html", error=None)

@app.post("/login")
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if valid_credentials(username, password):
        session["auth"] = True
        session["username"] = username
        return redirect(url_for("area"))
    return render_template("login.html", error="Usuário ou senha inválidos."), 401

@app.post("/api/login")
def api_login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if valid_credentials(username, password):
        return jsonify({"ok": True})
    return jsonify({"ok": False}), 401

@app.get("/area")
def area():
    if not session.get("auth"):
        return redirect(url_for("index"))
    return render_template("area.html", username=session.get("username", "aluno"))

@app.get("/download/desafio.enc")
def download():
    if not session.get("auth"):
        return redirect(url_for("index"))
    return send_file(DATA_FILE, as_attachment=True, download_name="desafio.enc")

@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.get("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, threaded=True)
